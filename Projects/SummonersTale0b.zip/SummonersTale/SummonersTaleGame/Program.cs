﻿
using var game = new SummonersTaleGame.Desktop();
game.Run();
