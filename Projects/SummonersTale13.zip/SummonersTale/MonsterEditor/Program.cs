﻿
using var game = new MonsterEditor.MonsterEditor();
game.Run();
