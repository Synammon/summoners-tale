﻿
using var game = new SummonersTaleGame.Game1();
game.Run();
