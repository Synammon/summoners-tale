﻿
using var game = new SummonersTaleEditor.Editor();
game.Run();
